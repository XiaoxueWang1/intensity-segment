const assert = require('assert');
const IntensitySegments = require('./intensitySegments');

function runTests() {
    // test1
    const seg1 = new IntensitySegments();
    assert.strictEqual(seg1.toString(), '[]');

    seg1.add(10, 30, 1);
    assert.strictEqual(seg1.toString(), '[[10,1],[30,0]]');

    seg1.add(20, 40, 1);
    assert.strictEqual(seg1.toString(), '[[10,1],[20,2],[30,1],[40,0]]');

    // test2
    seg1.set(15, 35, 5);
    assert.strictEqual(seg1.toString(), '[[10,1],[15,5],[35,1],[40,0]]');

    // test3
    seg1.add(10, 40, -3);
    assert.strictEqual(seg1.toString(), '[[10,-2],[15,2],[35,-2],[40,0]]');

    // test4
    const seg2 = new IntensitySegments();
    seg2.add(10, 30, 1);
    seg2.add(20, 40, 1);
    seg2.add(10, 40, -1);
    assert.strictEqual(seg2.toString(), '[[20,1],[30,0]]');

    // test5
    const seg3 = new IntensitySegments();
    seg3.add(10, 30, 1);
    seg3.add(20, 40, 1);
    seg3.add(10, 40, -1);
    seg3.add(10, 40, -1);
    assert.strictEqual(seg3.toString(), '[[10,-1],[20,0],[30,-1],[40,0]]');

    // test6
    const seg4 = new IntensitySegments();
    seg4.add(10, 10, 5);
    assert.strictEqual(seg4.toString(), '[]');

    seg4.add(10, 20, 0);
    assert.strictEqual(seg4.toString(), '[]');

    console.log('test pass!');
}

runTests();
