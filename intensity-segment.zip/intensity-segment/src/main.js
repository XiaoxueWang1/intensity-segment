// 创建实例
const IntensitySegments = require("./modules/intensity-segments");

const segments = new IntensitySegments();

// init
console.log(segments.toString()); // []

// add
segments.add(10, 30, 1);
console.log(segments.toString()); // [[10,1],[30,0]]

// add
segments.add(20, 40, 1);
console.log(segments.toString()); // [[10,1],[20,2],[30,1],[40,0]]

// set
segments.set(15, 35, 5);
console.log(segments.toString()); // [[10,1],[15,5],[35,1],[40,0]]

// add
segments.add(10, 40, -2);
console.log(segments.toString()); // [[10,-1],[15,3],[35,-1],[40,0]]
