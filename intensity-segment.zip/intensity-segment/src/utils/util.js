/**
 * Find the insertion position of the target value in ascending array (closed interval implementation)
 * @param {Array} nums - sorted ascending array
 * @param {number} target - the target value to be found
 * @returns {number} The index of the position where the target value should be inserted
 */

export function binarySearch(nums, target) {

    if (nums.length === 0) return 0;

    let left = 0;
    let right = nums.length - 1;

    if (target <= nums[left]) return 0;
    if (target > nums[right]) return nums.length;
    if (target === nums[right]) return right;

    while (left <= right) {
        const mid = left + Math.floor((right - left) / 2);
        if (nums[mid] < target) {
            left = mid + 1;
        } else if (nums[mid] > target) {
            right = mid - 1;
        } else {
            return mid;
        }
    }

    return left;
}

module.exports = {
    binarySearch
};
