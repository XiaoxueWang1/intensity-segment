const {binarySearch} = require("../utils/util");

class IntensitySegments {
    constructor() {
        /**
         * diff: The Diff Map -
         * Key: position
         * Val: Intensity[position] - Intensity[position-1]
         *
         * orderedPosition:
         * A sequential array of positions - since Map in JavaScript is not sorted by key
         */
        this.diff = new Map();
        this.orderedPosition = [];
    }

    /**
     * Update Diff Map
     * @param {number} position - the position need to update
     * @param {number} diffVal - the diff value
     * @returns
     */
    #updateDiff(position, diffVal) {
        const currentDiff = this.diff.get(position) || 0;
        const newDiff = currentDiff + diffVal;

        // if newDiff is 0, need delete it in diff and orderedPosition
        if (newDiff === 0) {
            this.diff.delete(position);
            const index = this.orderedPosition.indexOf(position);
            if (index !== -1) {
                this.orderedPosition.splice(index, 1);
            }
        } else { // update
            this.diff.set(position, newDiff);

            if (currentDiff === 0) { // insert into orderedPosition
                const insertPos = binarySearch(this.orderedPosition, position)
                this.orderedPosition.splice(insertPos, 0, position);
            }
        }
    }

    /**
     * Use prefix sum to calculate the intensity before position
     * @param {number} currPosition
     * @returns {number} - the intensity before currPosition
     */
    #getIntensityBefore(currPosition) {
        let intensity = 0;
        // prefix sum
        for (const pos of this.orderedPosition) {
            if (pos >= currPosition) break;
            intensity += this.diff.get(pos);
        }

        return intensity;
    }

    /**
     * Add intensity in [from, to)
     * @param {number} from - the start position of the interval (included)
     * @param {number} to - the end position of the interval (not included)
     * @param {number} amount - intensity need to be added
     */
    add(from, to, amount) {
        if (from >= to) return;
        // diff in from need add amount
        this.#updateDiff(from, amount);
        // diff in to need minus amount
        this.#updateDiff(to, -amount);
    }

    /**
     * Set intensity in [from, to)
     * @param {number} from - the start position of the interval (included)
     * @param {number} to - the end position of the interval (not included)
     * @param {number} amount - intensity need to be set
     */
    set(from, to, amount) {
        if (from >= to) return;

        const intensityBeforeFrom = this.#getIntensityBefore(from);
        const intensityBeforeTo = this.#getIntensityBefore(to);
        const diffTo = this.diff.get(to) || 0;

        // 1. delete all diffs inside interval
        for (let i = this.orderedPosition.length - 1; i >= 0; i--) {
            const pos = this.orderedPosition[i];
            if (pos > from && pos < to) {
                this.diff.delete(pos);
                this.orderedPosition.splice(i, 1);
            }
        }

        // 2. Update diff[from]
        this.#updateDiff(from, amount - intensityBeforeFrom);
        // 3. Update diff[to], Intensity[to] is "intensityBeforeTo + diffTo"
        this.#updateDiff(to, (intensityBeforeTo + diffTo) - amount);
    }

    /**
     * Get String representation of intensity interval
     * @returns {string} String representation of intensity interval
     */
    toString() {
        if (this.orderedPosition.length === 0) return "[]";

        const segments = [];
        let currentIntensity = 0;

        for (const pos of this.orderedPosition) {
            currentIntensity += this.diff.get(pos);
            segments.push([pos, currentIntensity]);
        }

        return JSON.stringify(segments);
    }
}

module.exports = IntensitySegments;
