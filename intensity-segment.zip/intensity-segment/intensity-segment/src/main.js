const IntensitySegments = require("./modules/intensity-segments");

const segments = new IntensitySegments();

// init
console.log("my new use case:")
console.log("init -- segments.toString()")
console.log(segments.toString()); // []

// add
console.log("add -- segments.add(10, 30, 1)")
segments.add(10, 30, 1);
console.log(segments.toString()); // [[10,1],[30,0]]

// add
console.log("add -- segments.add(20, 40, 1)")
segments.add(20, 40, 1);
console.log(segments.toString()); // [[10,1],[20,2],[30,1],[40,0]]

// set
console.log("set -- segments.set(15, 35, 5)")
segments.set(15, 35, 5);
console.log(segments.toString()); // [[10,1],[15,5],[35,1],[40,0]]

// add
console.log("add -- segments.add(10, 40, -2)")
segments.add(10, 40, -2);
console.log(segments.toString()); // [[10,-1],[15,3],[35,-1],[40,0]]

/*
my new use case:
init -- segments.toString()
[]
add -- segments.add(10, 30, 1)
[[10,1],[30,0]]
add -- segments.add(20, 40, 1)
[[10,1],[20,2],[30,1],[40,0]]
set -- segments.set(15, 35, 5)
[[10,1],[15,5],[35,1],[40,0]]
add -- segments.add(10, 40, -2)
[[10,-1],[15,3],[35,-1],[40,0]]
*/