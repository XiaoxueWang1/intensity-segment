class IntensitySegments {
    constructor() {
        /**
         * diff: The Diff Map -
         * Key: position
         * Val: Intensity[position] - Intensity[position-1]
         *
         * orderedPosition:
         * A sequential array of positions - since Map in JavaScript is not sorted by key
         */
        this.diff = new Map();
        this.orderedPosition = [];
    }

    /**
     * add Diff Map
     * @param {number} position - the position need to add
     * @param {number} diffVal - the diff value need to be added
     * @returns
	 * Time Complexity: O(n)
	 * Space Complexity: O(1)
     */
    #addDiff(position, diffVal) {
        const currentDiff = this.diff.get(position) || 0;
        const newDiff = currentDiff + diffVal;

        // if newDiff is 0, need delete it in diff and orderedPosition
        if (newDiff === 0) {
            this.diff.delete(position); // O(n)
			const index = this.#binarySearch(position); // O(logn)
			if (index >= 0 && index < this.orderedPosition.length && 
                this.orderedPosition[index] === position) {
                this.orderedPosition.splice(index, 1); // O(n)
            }
        } else { // update
            this.diff.set(position, newDiff);

            if (currentDiff === 0) { // insert into orderedPosition
                const insertPos = this.#binarySearch(position) // use binarySearch, O(logn)
                this.orderedPosition.splice(insertPos, 0, position); // O(n)
            }
        }
    }
	
	/**
	 * Find the index with a maximum value that is smaller than the target.
	 * @param {number} target - the target value
	 * @returns {number} the index with a maximum value that is smaller than the target
	 * Time Complexity: O(n)
	 * Space Complexity: O(1)
	 */
	#findLastLessThan(target) {
		let left = 0;
		let right = this.orderedPosition.length - 1;
		let index = -1;

		while (left <= right) {
			const mid = left + Math.floor((right - left) / 2);
			if (this.orderedPosition[mid] < target) {
				index = mid;
				left = mid + 1;
			} else {
				right = mid - 1;
			}
		}
		return index;
	}
	
	/**
	 * Find the insertion position of the target value in ascending array (closed interval implementation)
	 * @param {number} target - the target value to be found
	 * @returns {number} The index of the position where the target value should be inserted
	 * Time Complexity: O(n)
	 * Space Complexity: O(1)
	 */
	#binarySearch(target) {
		if (this.orderedPosition.length === 0) return 0;

		let left = 0;
		let right = this.orderedPosition.length - 1;

		if (target <= this.orderedPosition[left]) return 0;
		if (target > this.orderedPosition[right]) return this.orderedPosition.length;
		if (target === this.orderedPosition[right]) return right;

		while (left <= right) {
			const mid = left + Math.floor((right - left) / 2);
			if (this.orderedPosition[mid] < target) {
				left = mid + 1;
			} else if (this.orderedPosition[mid] > target) {
				right = mid - 1;
			} else {
				return mid;
			}
		}

		return left;
	}

    /**
     * Use prefix sum to calculate the intensity before position
     * @param {number} currPosition
     * @returns {number} - the intensity before currPosition
	 * Time Complexity: O(n)
	 * Space Complexity: O(1)
     */
	#getIntensityBefore(position) {
        if (this.orderedPosition.length === 0) return 0;
        
        const idx = this.#findLastLessThan(position);
        if (idx < 0) return 0;
        
        let intensity = 0;
        for (let i = 0; i <= idx; i++) {
            intensity += this.diff.get(this.orderedPosition[i]);
        }
        return intensity;
    }

    /**
     * Add intensity in [from, to)
     * @param {number} from - the start position of the interval (included)
     * @param {number} to - the end position of the interval (not included)
     * @param {number} amount - intensity need to be added
	 * Time Complexity: O(n)
	 * Space Complexity: O(1)
     */
    add(from, to, amount) {
        if (from >= to) return;
		
        // diff in from need add amount
        this.#addDiff(from, amount);
		
        // diff in to need minus amount
        this.#addDiff(to, -amount);
    }

    /**
     * Set intensity in [from, to)
     * @param {number} from - the start position of the interval (included)
     * @param {number} to - the end position of the interval (not included)
     * @param {number} amount - intensity need to be set
	 * Time Complexity: O(n)
	 * Space Complexity: O(n)
     */
    set(from, to, amount) {
        if (from >= to) return;

        const intensityBeforeFrom = this.#getIntensityBefore(from);
        const intensityBeforeTo = this.#getIntensityBefore(to);

		// 1. delete from startIdx to endIdx [startIdx, endIdx)
        let startIdx = this.#binarySearch(from); // O(logn)
		if(this.orderedPosition[startIdx] == from) { // no need delete from
			startIdx++;
		}
        const endIdx = this.#binarySearch(to);
		if (startIdx < endIdx) {
            const needRemovePos = this.orderedPosition.slice(startIdx, endIdx); // max O(n)
            needRemovePos.forEach(pos => this.diff.delete(pos)); // O(n)
            this.orderedPosition.splice(startIdx, endIdx - startIdx); // O(n)
        }

        // 2. Update diff[from]
		const diffFrom = this.diff.get(from) || 0;
        const diffTo = this.diff.get(to) || 0;
        this.#addDiff(from, amount - intensityBeforeFrom - diffFrom);
		
        // 3. Update diff[to], Intensity[to] is "intensityBeforeTo + diffTo"
        this.#addDiff(to, intensityBeforeTo - amount);
    }

    /**
     * Get String representation of intensity interval
     * @returns {string} String representation of intensity interval
	 * Time Complexity: O(n)
	 * Space Complexity: O(n)
     */
    toString() {
        if (this.orderedPosition.length === 0) return "[]";

        const segments = [];
        let currentIntensity = 0;

        for (const pos of this.orderedPosition) {
            currentIntensity += this.diff.get(pos);
            segments.push([pos, currentIntensity]);
        }

		// return json string
        return JSON.stringify(segments);
    }
}

module.exports = IntensitySegments;
