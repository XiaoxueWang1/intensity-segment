const assert = require('assert');
const IntensitySegments = require('../src/modules/intensity-segments');

function runTests() {
    // test1
    const seg1 = new IntensitySegments();
    assert.strictEqual(seg1.toString(), '[]');

    seg1.add(10, 30, 1);
    assert.strictEqual(seg1.toString(), '[[10,1],[30,0]]');

    seg1.add(20, 40, 1);
    assert.strictEqual(seg1.toString(), '[[10,1],[20,2],[30,1],[40,0]]');

    // test2
    seg1.set(15, 35, 5);
    assert.strictEqual(seg1.toString(), '[[10,1],[15,5],[35,1],[40,0]]');

    // test3
    seg1.add(10, 40, -3);
    assert.strictEqual(seg1.toString(), '[[10,-2],[15,2],[35,-2],[40,0]]');

    // test4
    const seg2 = new IntensitySegments();
    seg2.add(10, 30, 1);
    seg2.add(20, 40, 1);
    seg2.add(10, 40, -1);
    assert.strictEqual(seg2.toString(), '[[20,1],[30,0]]');

    // test5
    const seg3 = new IntensitySegments();
    seg3.add(10, 30, 1);
    seg3.add(20, 40, 1);
    seg3.add(10, 40, -1);
    seg3.add(10, 40, -1);
    assert.strictEqual(seg3.toString(), '[[10,-1],[20,0],[30,-1],[40,0]]');
	seg3.set(0, 1000000, 0);
	assert.strictEqual(seg3.toString(), '[]')

    // test6
    const seg4 = new IntensitySegments();
    seg4.add(10, 10, 5);
    assert.strictEqual(seg4.toString(), '[]');

    seg4.add(10, 20, 0);
    assert.strictEqual(seg4.toString(), '[]');
	
	const seg5 = new IntensitySegments();
	seg5.add(10, 30, 1);
	seg5.add(20, 40, 1);
	seg5.set(15, 25, 5);
	assert.strictEqual(seg5.toString(), '[[10,1],[15,5],[25,2],[30,1],[40,0]]');
	
	seg5.set(25, 40, 10);
	assert.strictEqual(seg5.toString(), '[[10,1],[15,5],[25,10],[40,0]]');
	
	seg5.add(10, 15, 4);
	assert.strictEqual(seg5.toString(), '[[10,5],[25,10],[40,0]]');
	seg5.add(10, 25, 5);
	assert.strictEqual(seg5.toString(), '[[10,10],[40,0]]');
	seg5.add(10, 40, -10);
	assert.strictEqual(seg5.toString(), '[]');

    console.log('test pass!');
}

runTests();
